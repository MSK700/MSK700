library(ggplot2)
library(ggplot)
library(corrplot)
library(data.table)
library(readr)
library(dplyr)
t = read.csv("C:/Users/fe/Downloads/QVI_transaction_data.csv", header = T)
c = read.csv("C:/Users/fe/Downloads/QVI_purchase_behaviour.csv", header = T)
str(t)
t = t[,-12]
t$DATE = as.Date(t$DATE, "%d-%m-%y")
str(c)
KOP = merge(c, t, by ="LYLTY_CARD_NBR")
str(KOP)
KOP$LYLTY_CARD_NBR = as.factor(KOP$LYLTY_CARD_NBR)
KOP$STORE_NBR = as.factor(KOP$STORE_NBR)
KOP$TXN_ID = as.factor(KOP$TXN_ID)
KOP$PROD_NBR =as.factor(KOP$PROD_NBR)
KOP$PROD_NAME = as.character(KOP$PROD_NAME)
KOP %>% select_if(is.numeric) %>%  cor() %>% corrplot()

#Module1 part2
summary(KOP)
summary(KOP$PROD_NAME)
plot(KOP$PROD_QTY,KOP$TOT_SALES)
KOP %>% filter(PROD_QTY==200)
KOP = KOP %>% filter(LYLTY_CARD_NBR != 226000)
ggplot(KOP, aes(x = Day, y = TOT_SALES)) +
  geom_line() +
  labs(x = "Day", y = "Total Sales", title = "Sales over time")
ggplot(KOP)+geom_boxplot(aes(x= PREMIUM_CUSTOMER,y = Day))

boxplot()
plot(KOP$DATE,KOP$TOT_SALES)

#little extra
productWords <- data.table(unlist(strsplit(unique(KOP$PROD_NAME), "")))
setnames(productWords, 'words')
library(stringr)
library(stringi)
productWords$words <- str_replace_all(productWords$words,"[[:punct:]]"," ")
productWords$words <- str_replace_all(productWords$words,"[0-9]"," ")
productWords$words <- str_replace_all(productWords$words,"[gG]"," ")
words.freq <- words.freq[order(words, decreasing = T),]
#till here
KOP$BRAND <- gsub("([A-Za-z]+).*", "\\1", KOP$PROD_NAME)
summarise(KOP)
summary(KOP)
KOP$PACKAGE_SIZE = parse_number(KOP$PROD_NAME)
#bp = as.factor(KOP$BRAND)
#summary(bp)
summary(KOP$PACKAGE_SIZE)
plot(KOP$PACKAGE_SIZE)
summary(as.factor(KOP$BRAND))
hist(KOP$PACKAGE_SIZE)
KOP$BRAND = gsub("Red","RRD", KOP$BRAND)
KOP$BRAND = gsub("Doritoss","Doritos", KOP$BRAND)
KOP$BRAND = gsub("Snbts","Sunbites", KOP$BRAND)
KOP$BRAND = gsub("Infzns","Infuzions", KOP$BRAND)
KOP$BRAND = gsub("WW","Woolworths", KOP$BRAND)
KOP$BRAND = gsub("NCC","Natural", KOP$BRAND)
KOP$BRAND = gsub("Smith","Smiths", KOP$BRAND)
KOP$BRAND = gsub("Grain","GrnWves", KOP$BRAND)

#applying RFM 
KOP %>% filter(LYLTY_CARD_NBR==162039)
KOP %>% filter(TXN_ID==162050)
analysis_date = max(KOP$DATE)
df_RFM <- KOP %>% 
  group_by(LYLTY_CARD_NBR) %>% 
  summarise(recency=as.numeric(analysis_date-max(DATE)),
            frequency =n_distinct(TXN_ID), monetary= sum(TOT_SALES))
summary(df_RFM)

#Scoring
#R_score
df_RFM$R_Score[df_RFM$recency>158.0]<-1
df_RFM$R_Score[df_RFM$recency>75.0 & df_RFM$recency<=158.0 ]<-2
df_RFM$R_Score[df_RFM$recency>29.0 & df_RFM$recency<=75.0 ]<-3
df_RFM$R_Score[df_RFM$recency<=29.0]<-4
#F_score
df_RFM$F_Score[df_RFM$frequency<1]<-1
df_RFM$F_Score[df_RFM$frequency>=1 & df_RFM$frequency<3]<-2
df_RFM$F_Score[df_RFM$frequency>=3 & df_RFM$frequency<5 ]<-3
df_RFM$F_Score[df_RFM$frequency>=5]<-4
#M_score
df_RFM$M_Score[df_RFM$monetary<= 9.10]<-1
df_RFM$M_Score[df_RFM$monetary>=9.10 & df_RFM$monetary<21.70]<-2
df_RFM$M_Score[df_RFM$monetary>=21.70 & df_RFM$monetary<40.00 ]<-3
df_RFM$M_Score[df_RFM$monetary>=40.00]<-4
#RFM_score
df_RFM<- df_RFM %>% mutate(RFM_Score = 100*R_Score + 10*F_Score+M_Score)

pp = read.csv("C:/Users/fe/Desktop/Saad/pp.csv")
df = merge(df_RFM,pp, by="RFM_Score")
KOP = merge(KOP,df, by="LYLTY_CARD_NBR")
